rangy-release
=============

Release of Rangy for Bower. Main project: https://github.com/timdown/rangy
