textangular-mathjax
===================

A mathjax editor to use with textacular


The code in this repository is just thrown over the wall, so expect some work to get it into a usable state.

## Dependencies

* Angualar 
* textangular (naturally)
* MathJax 

## Usage

1. Include the editor-directive and tune your template paths.

2. Add something like this to your code:

<div gt-editor id="my-editor" ng-model="content"></div>

And you should get an editor.




